const Directives = {
    install: function(Vue) {
        //通用指令
        Vue.directive('sd-role', require('./common/role.js').default);
        // Vue.directive('sd-auth', require('./common/auth.js').default);
    }
};

// 导出指令
export default Directives;
