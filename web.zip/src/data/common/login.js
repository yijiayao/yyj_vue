export default {
    "ok": true,
    "code": 1,
    "mess": "成功",
    "data": null
};
