import zhLocale from 'element-ui/lib/locale/lang/zh-CN';
const cn = {
    message: {
        'hello': '你好，世界',
        'msg': '提示',
        'switchEnglish': '切换英文',
        'switchingChinese': '切换中文',
        'homePage': '首页',
    }  
};

export default Object.assign(cn, zhLocale);
