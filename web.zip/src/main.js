import Vue from 'vue';
import VueRouter from 'vue-router';
import Promise from 'promise-polyfill';
import Routers from './router';
import Util from './libs/util';
import VueI18n from 'vue-i18n';
import 'element-ui/lib/theme-chalk/index.css';
import i18n from './i18n/i18n';

import ElementUI  from 'element-ui';
import App from './app.vue';
import CustComponents from './components';
import CustDirectives from './directives';
import axios from "axios";
import crypto from "crypto-js";
import "./styles/theme_default.less";
import "./styles/iconfont/iconfont.css";    //.class为el-icon-pile-XXX
import "babel-polyfill";
import './assets/rem.js';
import 'echarts/map/js/china.js'
//事件bus 兄弟传值车
window.eventBus = new Vue();
//事件名称
window.eventname = ["typedata", "waringdata"]
global.Promise = Promise;
global.vue = new Vue();
global.UEDITOR_HOME_URL = (process.env.NODE_ENV && process.env.NODE_ENV === "production") ?
    "/dist/assets/ueditor/" : "/src/assets/ueditor/";
Vue.use(VueRouter);
Vue.use(CustComponents);
Vue.use(CustDirectives);
Vue.use(ElementUI);

// Vue.use(VueI18n);
// Vue.use(Element);
// Vue.use(Loading.directive);
Vue.config.lang = 'zh-CN';
Vue.config.productionTip = false
    // Vue.locale('zh-cn', zhLocale);
    // Vue.locale('en', enLocale);

// Vue.prototype.$loading = Loading.service;
// Vue.prototype.$msgbox = MessageBox;
// Vue.prototype.$alert = MessageBox.alert;
// Vue.prototype.$confirm = MessageBox.confirm;
// Vue.prototype.$prompt = MessageBox.prompt;
// Vue.prototype.$notify = Notification;
// Vue.prototype.$message = Message;

global.log = function() {};
// ({ log: global.custLog } = console);


// 模拟数据mock启动，在生产环境时可注释掉
// require("./config/mockconf").default.start();
require("./config/config.js");

// 路由配置
const RouterConfig = {
    // mode: 'history',
    routes: Routers
};
const router = new VueRouter(RouterConfig);


// const messages = {
//     zh: {
//       message: {
//         hello: '好好学习，天天向上！'
//       }
//     },
//     en: {
//       message: {
//         hello: 'good good study, day day up!'
//       }
//     }
// };
//   const i18n = new VueI18n({
//     locale: 'en', // set locale
//     messages, // set locale messages
//   })

//   Vue.use(ElementUI, {
//     i18n: (key, value) => i18n.t(key, value)
//   })
//   const app = new Vue({
//     i18n,
// }).$mount('#app')
// router.beforeEach((to, from, next) => {
//     iView.LoadingBar.start();
//     Util.title(to.meta.title);
//     next();
// });

// router.afterEach((to, from, next) => {
//     iView.LoadingBar.finish();
//     window.scrollTo(0, 0);
// });

let requestMap = {};

let buildKeyByConfig = function(config) {
    let data = config.data;
    if (typeof data !== "string") {
        data = JSON.stringify(data);
    }
    return crypto.MD5(config.url + data);
};

let loading = 0;
axios.interceptors.request.use(
    config => {
        // if (loading === 0) {
        //     loading++;
        //     global.vue.$emit("spin-show", {});
        // } else {
        //     loading++;
        // }
        let key = buildKeyByConfig(config);
        if (!requestMap[key]) {
            requestMap[key] = 1;
            return config;
        } else {
            return null;
        }
    },
    error => {
        // Do something with request error
        return Promise.reject(error);
    }
);

axios.interceptors.response.use(
    response => {
        // if (loading === 1) {
        //     loading--;
        //     global.vue.$emit("spin-hide", {});
        // } else {
        //     loading--;
        // }
        let key = buildKeyByConfig(response.config);
        requestMap[key] = 0;
        if (!response.data.ok && response.data.code === -101004) {
            // window.logout();
        } else {
            return response;
        }
    },
    error => {
        if (loading === 1) {
            loading--;
            global.vue.$emit("spin-hide", {});
        } else {
            loading--;
        }
        if (error.response) {
            switch (error.response.status) {
                case 401:
                    // 返回 401 清除token信息并跳转到登录页面
                    router.replace({
                        path: '/login',
                        query: { redirect: router.currentRoute.fullPath }
                    });
                    // window.logout();                
                    // console.log(this.$route.path);
                    // if (this.$route.path != '/login') {
                    //     window.logout();
                    // }
                    break;
                default:
                    break;
            }

            let key = buildKeyByConfig(error.response.config);
            requestMap[key] = 0;
        }
        // 返回接口返回的错误信息
        return Promise.reject(error);
    }
);

const isIE = function() {
    return (window.navigator.userAgent.indexOf("MSIE") >= 1);
};

// 修复IE10及以下版本不支持dataset属性的问题，兼容transfer-dom.js中使用了dataset的问题
if (isIE() && window.HTMLElement) {
    if (Object.getOwnPropertyNames(HTMLElement.prototype).indexOf('dataset') === -1) {
        Object.defineProperty(HTMLElement.prototype, 'dataset', {
            get: function() {
                let attributes = this.attributes;
                let name = [];
                let value = [];
                var obj = {};
                for (let i = 0; i < attributes.length; i++) {
                    if (attributes[i].nodeName.slice(0, 5) === 'data-') {
                        name.push(attributes[i].nodeName.slice(5));
                        value.push(attributes[i].nodeValue);
                    }
                }
                for (let j = 0; j < name.length; j++) {
                    obj[name[j]] = value[j];
                }
                return obj;
            }
        });
    }
}

new Vue({
    el: '#app',
    router: router,
    Routers,
    // i18n,
    components: { App },
    template: '<App/>',
    render: h => h(App)
});
