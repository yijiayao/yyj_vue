//拿到对应设备的宽度值
//1.window.innerWidth

//2.document.documentElement.clientWidth

var init = function () {
    var width = document.documentElement.clientWidth;
    //获取设备的宽度
    document.documentElement.style.fontSize = width / 19.2 + 'px';
};
init();
//orientationchange 监听手机旋转的事件的时机
window.addEventListener('orientationchange', init);
//监听窗口改变
window.addEventListener('resize', init);
