import Env from './env';
import util from '@/libs/util.js';

// global.API_PREFIX = 'http://localhost:8090';
global.API_PREFIX = '/charger';


window.logout = function() {
    let account = util.locals.get("account");
    const token = {};
    token["token"] = util.locals.get("token");
    global.SERVER_HEADER["token"] = util.locals.get("token");
    util.request(global.API_PREFIX + '/logout/' + account, token).then((response) => {
        if (response.data.success) {
            window.location.href = "/#/login";
            if (!!window.ActiveXObject || "ActiveXObject" in window) {
                window.location.reload();
            }
        }
    }).catch((e) => {
        util.handleError(e);
        window.location.href = "/#/login";
        // window.parent.location.href = "/#/login";
    });
};

let config = {
    env: Env
};
export default config;
