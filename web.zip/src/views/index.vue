<style scoped lang="less">
    .index {
        position: fixed;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        background-color: #F8F8FF;
        display: flex;
    }

    .left-block {
        width: 15%;
        height: 100%;
        background-color: #00a2d4;

        .left-header {
            width: 100%;
            height: 25%;
            background-color: #3b3b3b;
        }

        .left-menu {
            height: 75%;
            border-right: 1px solid #3b3b3b;
        }
    }

    .right-block {
        width: 85%;
        height: 100%;

        .main-header {
            height: 8%;
            width: 100%;
            background-color: #6C7B8B;
            display: flex;
            align-items: center;
            padding: 0 30px;
        }

        .main-content {
            height: 92%;
            width: 100%;
            overflow-y: auto;
            overflow-x: hidden;
            padding: 1.5vh;
        }

        .section-menu {
            position: absolute;
            left: 15%;
            top: 0;
            bottom: 0;
            width: 15%;
            height: 100%;
            background-color: #E5E5E5;
            box-sizing: border-box;
            z-index: 999;

            .section-menu-header {
                height: 10%;
                display: flex;
                align-items: center;
                font-weight: bold;
            }
        }

    }
</style>
<template>
    <div class="index">
        <div class="left-block">
            <div class="left-header"></div>
            <el-menu
                    background-color="#3b3b3b"
                    default-active="2"
                    class="left-menu">
                <el-submenu index="1">
                    <template slot="title">
                        <i class="el-icon-location"></i>
                        <span>导航一</span>
                    </template>
                    <el-menu-item-group>
                        <template slot="title">分组一</template>
                        <el-menu-item index="1-1">选项1</el-menu-item>
                        <el-menu-item index="1-2">选项2</el-menu-item>
                    </el-menu-item-group>
                    <el-menu-item-group title="分组2">
                        <el-menu-item index="1-3">选项3</el-menu-item>
                    </el-menu-item-group>
                    <el-submenu index="1-4">
                        <template slot="title">选项4</template>
                        <el-menu-item index="1-4-1">选项1</el-menu-item>
                    </el-submenu>
                </el-submenu>
                <el-menu-item index="2">
                    <i class="el-icon-menu"></i>
                    <span slot="title">导航二</span>
                </el-menu-item>
                <el-menu-item index="3" disabled>
                    <i class="el-icon-document"></i>
                    <span slot="title">导航三</span>
                </el-menu-item>
                <el-menu-item index="4">
                    <i class="el-icon-setting"></i>
                    <span slot="title">导航四</span>
                </el-menu-item>
            </el-menu>
        </div>
        <div class="right-block">
            <transition name="el-zoom-in-center">
                <div v-show="sectionShow" class="section-menu ">
                    <div class="section-menu-header">
                    <span style="font-size: 20px">选择科室</span>
                    </div>
                </div>
            </transition>
            <div class="main-header">
                <div @click="selectSection" style="color: white" class="clickable">
                    <i class="iconfont icon-category" style="font-weight: bold;font-size: 14px"></i>
                    <span>选择科室</span>
                </div>
            </div>
            <div class="main-content">
                <div style="min-height: 100%;background-color: #fff">
                    <router-view></router-view>
                </div>
            </div>

        </div>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                sectionShow: false
            };
        },
        methods: {
            selectSection() {
                this.sectionShow = true;
            }
        },
        created() {

        }
    };
</script>
