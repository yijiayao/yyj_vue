<style lang="less" scoped>
@import "../styles/difinitions.less";
@content-width: 960px;
.layout-logo-left{
    width: 12.5%;
    background-image: url(../images/logo.png);
    background-position: 50% 50%;
    background-repeat: no-repeat;
    background-size: auto 50%;
    display: inline-block;
    vertical-align: middle;
}
.single-title-content-block {
    display: inline-block;
    width: 100%;
    height: @l-title-height;
    background-color: @c-main;
    .single-title-block-container {
        position: relative;
        margin: 0 auto;
        width: @content-width;
        height: 100%;
    }
    .right-container {
        float: right;
        line-height: 60px;
        &::after {
            content: "";
            display: block;
            clear: both;
        }
    }
}
.title-content-right {
    display: inline-block;
    padding: 15px 30px;
    box-sizing: border-box;
    vertical-align: middle;
}
.single-title-text {
    .font-m();
    color: @c-white;
}
.single-main-content-block {
    position: relative;
    margin: 0 auto;
    width: @content-width;
}
</style>

<style lang="less">
@import "../styles/difinitions.less";
.exit-button {
    color: @c-white;
    .ivu-icon,span {
        color: @c-white;
    }
}
</style>

<template>
    <div>
        <div class="single-title-content-block">
            <div class="single-title-block-container">
                <div class="layout-logo-left title-height-block">
                </div><div class="title-content-right">
                    <div class="single-title-text">{{title}}</div>
                </div>
                <div class="right-container"><Button @click="logout" icon="off" type="text" class="exit-button">退出</Button></div>
            </div>
        </div>
        <div class="single-main-content-block">
            <router-view></router-view>
        </div>
    </div>
</template>

<script>
export default {
    data() {
        return {
            title: ""
        };
    },
    created() {
        this.title = this.$route.meta.title;
    },
    methods: {
        logout() {
        }
    }
};
</script>

