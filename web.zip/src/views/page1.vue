<template>
    <div style="padding: 20px">
        <elDateRange @change="getDateRange"></elDateRange>
        <el-radio-group v-model="radio3">
            <el-radio-button label="上海"></el-radio-button>
            <el-radio-button label="北京"></el-radio-button>
        </el-radio-group>
        <el-input
                placeholder=""
                suffix-icon="el-icon-search"
                v-model="input2">
        </el-input>
        <el-table
                :data="tableData"
                border
                stripe
                style="width: 1000px;">
            <el-table-column
                    prop="date"
                    label="日期"
                    width="180">
            </el-table-column>
            <el-table-column
                    prop="name"
                    label="姓名"
                    width="180">
            </el-table-column>
            <el-table-column
                    prop="address"
                    label="地址">
            </el-table-column>
        </el-table>

    </div>
</template>

<script>
    export default {
        data() {
            return {
                radio3: '上海',
                tableData: [{
                    date: '2016-05-02',
                    name: '王小虎',
                    address: '上海市普陀区金沙江路 1518 弄'
                }, {
                    date: '2016-05-04',
                    name: '王小虎',
                    address: '上海市普陀区金沙江路 1517 弄'
                }, {
                    date: '2016-05-01',
                    name: '王小虎',
                    address: '上海市普陀区金沙江路 1519 弄'
                }, {
                    date: '2016-05-03',
                    name: '王小虎',
                    address: '上海市普陀区金沙江路 1516 弄'
                }],
                input2: ''
            };
        },
        methods: {
            getDateRange(val) {
                console.log(val);
            }
        }

    };
</script>

<style scoped>

</style>
