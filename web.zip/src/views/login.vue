<style lang="less">
    @import "../styles/difinitions.less";

</style>

<template>
    <div>
        <el-button @click="$router.push('/index')">登录</el-button>
    </div>
</template>
<script>
    import util from "@/libs/util.js";

    export default {
        data() {
            return {
                loginForm: {
                    username: "",
                    password: ""
                },
                formRule: {
                    username: [
                        {required: true, message: "请填写用户名", trigger: "blur"}
                    ],
                    password: [{required: true, message: "请填写密码", trigger: "blur"}]
                }
            };
        },
        created() {
            util.locals.clearLocalStorage();
            window.vue.$emit("on-clear-cache");
        },
        methods: {
            handleSubmit(formName) {
                let _this = this;
                let sha256 = require("js-sha256").sha256; //引入sha256库 进行密码加密
                let password = sha256(formName.password);
                util.request(global.API_PREFIX + "/login", {
                    username: formName.username,
                    password: password
                })
                    .then(function (response) {
                        let success = response.data.success === false ? 1 : 0;
                        if (success) {
                            alert(response.data.description);
                        } else {
                            util.locals.set("token", response.data.token);
                            global.SERVER_HEADER = {};
                            global.SERVER_HEADER["Authorization"] = "Bearer" + " " + util.locals.get("token");
                            _this.cacheLoginInfo();
                            // _this.$router.push("homePage"); Authorization 存储token值
                        }
                    });
            },

            //保存登录信息
            cacheLoginInfo() {
                let _this = this;
                util
                    .requestget(global.API_PREFIX + "/getLoginedData")
                    .then(function (response) {
                        const loginData = response.data;
                        const auths = loginData.permissions;
                        util.locals.set(
                            "account",
                            JSON.stringify(loginData.loginUser.account)
                        );
                        util.locals.set("USER_AUTHS", JSON.stringify(auths));
                        _this.$router.push("homePage");
                    });
            }
        }
    };
</script>

