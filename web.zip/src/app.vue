<style lang="less">
    @import "styles/common.less";
    @import "styles/difinitions.less";
    @import "styles/theme_default.less";

    body {
        margin: 0;
    }
    body {
        height: 100%;
        width: 100%;
        overflow: hidden;
    }

</style>

<template>
    <div class="app">
        <router-view/>
    </div>

</template>


