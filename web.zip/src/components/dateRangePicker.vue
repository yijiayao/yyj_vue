<template>
    <div class="dateRangePicker">
        <el-date-picker v-model="start"
                        placeholder="选择日期"
                        value-format="yyyy-MM-dd"
                        :editable="false"
                        class="picker"></el-date-picker>
        <el-date-picker v-model="end"
                        class="picker"
                        value-format="yyyy-MM-dd"
                        :editable="false"
                        placeholder="选择日期"></el-date-picker>
        <el-button @click="submitClick">查询</el-button>
    </div>
</template>

<script>
    import dateUtil from '../libs/dateUtil';
    export default {
        data() {
            return {
                start: "",
                end: ""
            };
        },
        methods: {
            submitClick() {
                this.$emit("change", {
                    startTime: this.start,
                    endTime: this.end
                });
            }
        },
        watch: {
            start(val) {
                if (dateUtil.dateCompare(val, this.end) > 0) {
                    this.start = this.end;
                }
            },
            end(val) {
                if (dateUtil.dateCompare(val, this.start) < 0) {
                    this.end = this.start;
                }
            }
        }
    };
</script>

<style lang="less">
    .dateRangePicker {
        display: flex;
        align-items: center;

        .picker {
            margin-right: 10px;
        }
    }

</style>
