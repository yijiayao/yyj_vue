const Components = {
    install: function(Vue) {
        //通用组件

        Vue.component('elDateRange', require("./dateRangePicker.vue"));
    }
};

// 导出组件
export default Components;
