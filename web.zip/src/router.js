const routers = [
    {
        path: '/',
        redirect: '/login'
    },
    {
        path: '/login',
        component: (resolve) => require(['./views/login.vue'], resolve)
    },
    {
        path: '/index',
        component: (resolve) => require(['./views/index.vue'], resolve),
        redirect: 'index/1',
        children: [
            {
                path: '1',
                component: (resolve) => require(['./views/page1.vue'], resolve)
            },
        ]
    }

];
export default routers;
