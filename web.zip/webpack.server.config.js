const path = require('path');
const CopyWebpackPlugin = require('copy-webpack-plugin');
var fs = require('fs');

var defaultOpt = {
    "httpPort": "8080",
    "httpsPort": "8443",
    "httpRedictPort": "443",
    "serverUrl": "http://localhost:8088"
};

fs.open('./target/env.json', 'w', function(err, fd) {
    const buf = JSON.stringify(defaultOpt, null, 4);
    fs.write(fd, buf, 0, buf.length, 0, function (_err, written, buffer) {});
});

module.exports = {
    entry: {
        server: './src/server'
    },
    target: "node",
    output: {
        path: path.join(__dirname, './target'),
        filename: '[name].js'
    },
    plugins: [
        new CopyWebpackPlugin([
            { from: './src/secure', to: './secure' }
        ])
    ]
};
