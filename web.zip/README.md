# 前端

本项目使用前后端分离的开发模式，前端由vue+element-ui实现。

其中涉及到的技术有：
- webpack
- node
- es6
- vue
- less (用来定义ui风格变量)
- mockjs

开发工具 vscode、webstorm

## 安装

下载完代码后在命令窗口中运行

```bash
npm install
```

运行前需要检查本地是否有npm命令

```bash
npm --version
```

如果提示没有此命令，下载nodejs并安装

## 运行
### 开发模式
开发时运行以下命令

```bush
npm run dev
```
运行后项目支持热重启，即修改完代码后只需要刷新浏览器即可，插件会自动编译，不用重新运行

### 生产模式
```bush
npm run build
```

## 开发

### 工程目录说明

```
|-dist (在运行npm run build后会出现，为编译后的压缩代码，不加入版本控制)
|-node_modules (在运行npm install后会出现，为依赖模块，不加入版本控制)
|-src (工程源码，源码编译后将放到dist目录中)
|  |-assets
|  |-components (自定义组件，添加vue文件后需要在index.js内注册)
|  |-config
|  |  config.js
|  |  env.js (自动生成，标记当前环境是否为开发环境，不加入版本控制)
|  |  mockconf.js (在mockconf目录中新加一接口归类文件后需要在此注册)
|  |
|  |-data (模拟数据存放文件夹，可定义mock数据模板)
|  |-images (图片路径)
|  |-libs (自定义函数工具)
|  |-styles (外部定义的样式文件)
|  |-template (编译生成主页面的模板文件)
|  |-views (编写的页面都放在这里，根据路由来绑定页面)
|  app.vue 
|  main.js
|  router.js (路由文件，将路由和views目录下问页面文件绑定)
|  server.js
|  vendors.js
.babelrc (配置babel)
.eslintignore (配置eslint忽略文件)
.eslintrc.json (配置eslint规则)
.stylelintrc.json (配置stylelint规则)
index.html
LICENSE
package.json (配置npm)
README.md
webpack.base.conf.js
webpack.dev.conf.js
webpack.prod.conf.js
webpack.server.config.js
```

### UI规范定义

- 根据UI规范，本项目将UI规范参数定义于difinitions.less文件中

- 组件的样式建议使用less书写

- 当样式中需要用到difinitions.less中定义的变量和mixin，需要引入定义文件，如下

```less
@import "../../styles/difinitions.less";
```

### 编码规范说明

#### Javascript

- 自定义函数需要有文档注释，包含：函数说明，参数类型，参数名，参数说明，返回值类型，返回说明，格式示例如下：

``` javascript
/**
* 给菜单列表添加对应等级的子菜单
* @param {map<string,object>} parentMenuMap 父菜单的键值对
* @param {object} childMenuItem 子菜单项
* @param {integer} level 子菜单级别
* @returns {list<object>} 返回添加子菜单后的结果列表
*/
```

- 二元运算符与操作变量间需要有空格，一元运算符与操作变量间不能有空格

- 点运算符前后不能有空格

- 对象键值对中的冒号后需要有空格

- 函数参数列表括号和参数列表间不能有空格

- 逗号操作符后需要加空格，逗号前不加空格

- 缩进为4个空格，代码块需要有正确缩进

- this的别名只能定义为_this

- 本项目中使用es6规范，需要严格使用let和const定义变量或常量，避免使用var定义

#### Vue书写规范

##### 必要

-   组件名为多个单词
   
-   组件的data必须是一个函数
   
-   prop定义应该尽量详细
   
-   为v-for设置键值
   
-   为组件样式设置作用域
   
-   私有属性名前缀 $_

#####

-   其他详见__(Vue风格指南)[https://cn.vuejs.org/v2/style-guide/]__