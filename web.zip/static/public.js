window.MPARAMS = {
    "consoleIcpNO": "沪ICP备10030500号-12"
};
