const webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ExtractTextPlugin = require('extract-text-webpack-plugin');
const merge = require('webpack-merge');
const webpackBaseConfig = require('./webpack.base.config.js');
const fs = require('fs');

fs.open('./src/config/env.js', 'w', function(err, fd) {
    const buf = 'export default "development";\n';
    fs.write(fd, buf, 0, buf.length, 0, function(_err, written, buffer) {});
});

module.exports = merge(webpackBaseConfig, {
    devtool: '#source-map',
    output: {
        publicPath: '/dist/',
        filename: '[name].js',
        chunkFilename: '[name].chunk.js'
    },
    devServer: {
        //publicPath: '/dist/',
        port: 8090,
        disableHostCheck: true,
        proxy: {
            '/charger/*': {
                //gqs
                //账号111@12.com
                //密码1qaz!QAZ
                // target: 'http://10.40.143.130:8088',
                // target: 'https://10.40.139.69:9080',
                // target: 'https://10.40.138.150:9080',
                // target: 'https://10.40.139.69:9080',jmnmnj
                // target: 'https://10.40.138.178:9080',
                // target: 'https://10.40.138.78:9080',
                // target: 'https://10.40.139.65:9080',
                // target: 'http://114.115.169.46:8088',
                target: 'http://139.159.134.139:8088',
                secure: false
            }
        }
    },
    plugins: [
        new ExtractTextPlugin({
            filename: '[name].css',
            allChunks: true
        }),
        new webpack.optimize.CommonsChunkPlugin({
            name: 'vendors',
            filename: 'vendors.js'
        }),
        new HtmlWebpackPlugin({
            filename: '../index.html',
            template: './src/template/index.ejs',
            inject: false
        }),
        // new HtmlWebpackPlugin({
        //     filename: '../auth.html',
        //     template: './src/template/auth.ejs',
        //     inject: false
        // }),
        new webpack.NormalModuleReplacementPlugin(/element-ui[\/\\]lib[\/\\]locale[\/\\]lang[\/\\]zh-CN/, 'element-ui/lib/locale/lang/en')
    ]
});
